#include <qb_force_control.h>
#include "ros/ros.h"


#include <std_msgs/Float32MultiArray.h>
float Arr[6];

void arrayCallback(const std_msgs::Float32MultiArray::ConstPtr& array);

int main(int argc, char **argv)
{


  //state.closure.clear();
	ros::init(argc, argv, "FSRtoClosure");
	ros::NodeHandle n;
  ros::Subscriber sub = n.subscribe("sensors_FSR", 100, arrayCallback);
	ros::Publisher pub = n.advertise<qb_interface::handRef>("/qb_class/hand_ref", 100);

  qb_interface::handPos state;
//ros::Rate loop_rate(10); //10hz
	while (ros::ok())
	{

    float value=0;
		state.closure.clear();

		std_msgs::Float32MultiArray array;

    ros::spinOnce();
//start arduino values
/*
for(int j = 0; j < 6; j++){
//			printf("%f, ", Arr[j]);
      value+=Arr[j];
		}
		value=value*100;
//		printf("\n");
if( value > 230000){
value = 230000;
}
state.closure.push_back(value);

pub.publish(state);
sleep(1);
*/
//end arduino values

// start step closure test

for (int j =1; j < 11 ; j++){
value=10000;
state.closure.clear();
state.closure.push_back(value*j+100000);

pub.publish(state);
sleep(1);


}

//end step closure test

	//	loop_rate.sleep();
    }
//210000 e' il valore massimo se id mano 1



//sleep(2);

}

void arrayCallback(const std_msgs::Float32MultiArray::ConstPtr& array)
{

	int i = 0;
	// print all the remaining numbers
	for(std::vector<float>::const_iterator it = array->data.begin(); it != array->data.end(); ++it)
	{
		Arr[i] = *it;
		i++;
	}

}
