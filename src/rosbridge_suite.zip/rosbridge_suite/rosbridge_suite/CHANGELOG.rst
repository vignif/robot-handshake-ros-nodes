^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rosbridge_suite
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.9.0 (2018-04-09)
------------------

0.8.6 (2017-12-08)
------------------

0.8.5 (2017-11-23)
------------------

0.8.4 (2017-10-16)
------------------

0.8.3 (2017-09-11)
------------------

0.8.2 (2017-09-11)
------------------

0.8.1 (2017-08-30)
------------------

0.8.0 (2017-08-30)
------------------

0.7.17 (2017-01-25)
-------------------

0.7.16 (2016-08-15)
-------------------

0.7.15 (2016-04-25)
-------------------
* changelog updated
* Contributors: Russell Toris

0.7.14 (2016-02-11)
-------------------

0.7.13 (2015-08-14)
-------------------

0.7.12 (2015-04-07)
-------------------

0.7.11 (2015-03-23)
-------------------

0.7.10 (2015-02-25)
-------------------

0.7.9 (2015-02-24)
------------------

0.7.8 (2015-01-16)
------------------

0.7.7 (2015-01-06)
------------------

0.7.6 (2014-12-26)
------------------
* 0.7.5
* update changelog
* 0.7.4
* changelog updated
* 0.7.3
* changelog updated
* 0.7.2
* changelog updated
* 0.7.1
* update changelog
* 0.7.0
* changelog updated
* Contributors: Jihoon Lee, Russell Toris

0.7.5 (2014-12-26)
------------------

0.7.4 (2014-12-16)
------------------

0.7.3 (2014-12-15)
------------------

0.7.2 (2014-12-15)
------------------
* 0.7.1
* update changelog
* Contributors: Jihoon Lee

0.7.1 (2014-12-09)
------------------

0.7.0 (2014-12-02)
------------------

0.6.8 (2014-11-05)
------------------

0.6.7 (2014-10-22)
------------------
* updated package manifests
* Contributors: Russell Toris

0.6.6 (2014-10-21)
------------------

0.6.5 (2014-10-14)
------------------
* 0.6.4
* update changelog
* 0.6.3
* update change log
* Contributors: Jihoon Lee

0.6.4 (2014-10-08)
------------------

0.6.3 (2014-10-07)
------------------

0.6.2 (2014-10-06)
------------------

0.6.1 (2014-09-01)
------------------

0.6.0 (2014-05-23)
------------------

0.5.4 (2014-04-17)
------------------

0.5.3 (2014-03-28)
------------------

0.5.2 (2014-03-14)
------------------

0.5.1 (2013-10-31)
------------------

0.5.0 (2013-07-17)
------------------
* 0.5.0 preparation for hydro release
* Contributors: Jihoon Lee

0.4.4 (2013-04-08)
------------------
* adding russl and myself as maintainer. adding build_tool depend
* Contributors: Jihoon Lee

0.4.3 (2013-04-03 08:24)
------------------------
* adding CMake list for meta pkg
* Contributors: Jihoon Lee

0.4.2 (2013-04-03 08:12)
------------------------

0.4.1 (2013-03-07)
------------------

0.4.0 (2013-03-05)
------------------
* cleaning up meta package
* Catkinizing rosbridge_library and server.
* Collapse directory structure.
* Removed print statements and also made sure to cast any tuples to lists.
* Removed the pypng dependency and finalised PIL dependency
* Use python imaging library to encode PNG instead of pypng
* Added the ujson library, modified cmakelists to install ujson to the
  user python directory.
* Fixed an inconsequential elif bug.
* Refactored to use simplejson if the package is installed.
* Added simplejson library and moved the location of the libraries.
* Temporary commit adding profiling messages. something is goign awry.
* Renamed rosbridge stack to rosbridge_suite
* Contributors: Austin Hendrix, Brandon Alexander, Jihoon Lee, jon
